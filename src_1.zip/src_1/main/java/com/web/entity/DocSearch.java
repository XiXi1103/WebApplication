package com.web.entity;

public class DocSearch {
    public String title;
    public int id;

    public DocSearch() {}

    public DocSearch(String title, int id) {
        this.title = title;
        this.id = id;
    }
}
