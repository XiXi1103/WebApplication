package com.web.entity.ReturnResult;

public class RemoveRecentBrowsingResult {
    public boolean success;
}
