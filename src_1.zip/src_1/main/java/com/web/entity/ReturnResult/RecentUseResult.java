package com.web.entity.ReturnResult;

import java.util.ArrayList;

public class RecentUseResult {
    ArrayList<DocumentationResult> documentationResults;
}
