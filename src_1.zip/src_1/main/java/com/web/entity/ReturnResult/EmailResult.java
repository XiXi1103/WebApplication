package com.web.entity.ReturnResult;

public class EmailResult {
    public boolean success;
}
