package com.web.entity.ReturnResult;

import com.web.entity.User;

import java.util.List;

public class MyDocResult {
    public List<PageList> pageList;
    public List<User> writerList;
}
