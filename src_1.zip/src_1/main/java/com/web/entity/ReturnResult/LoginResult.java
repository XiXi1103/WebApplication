package com.web.entity.ReturnResult;

public class LoginResult {
    public boolean success;
    public int ID;
    public String msg;
}
