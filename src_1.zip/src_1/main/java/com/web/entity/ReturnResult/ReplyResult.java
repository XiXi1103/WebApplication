package com.web.entity.ReturnResult;

import com.web.entity.Reply;

import java.util.List;

public class ReplyResult {
    public List<Reply> replyList;
    public String msg;
    public boolean success;
}
