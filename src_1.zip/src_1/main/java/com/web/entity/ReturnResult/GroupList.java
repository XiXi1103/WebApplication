package com.web.entity.ReturnResult;

public class GroupList {
    public int id;
    public String name;
    public boolean isCreator;
}
