package com.web.entity.ReturnResult;

public class DocumentationResult {
    public String documentationTitle;
    public int documentationId;
    public boolean isCreator;
}
