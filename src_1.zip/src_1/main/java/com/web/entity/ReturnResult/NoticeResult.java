package com.web.entity.ReturnResult;

public class NoticeResult {
    public String msg;
    public String date;
    public int id;
    public int category;
    public int objectID;
    public boolean status;
    public String name;
}
