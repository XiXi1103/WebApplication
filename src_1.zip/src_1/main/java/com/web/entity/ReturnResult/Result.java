package com.web.entity.ReturnResult;

public class Result {
    public boolean success;
    public int ID;
    public String msg;
    public String url;
    public String result;
}
