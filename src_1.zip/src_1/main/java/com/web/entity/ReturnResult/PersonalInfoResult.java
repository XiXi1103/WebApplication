package com.web.entity.ReturnResult;

public class PersonalInfoResult {
    public String username;
    public String password;
    public String email;
    public String phoneNum;
    public String create_time;
    public boolean success;
    public String msg;
    public boolean isOther;
}
