package com.web.entity.ReturnResult;

public class RegisterResult {
    public boolean success;
    public int ID;
    public String msg;
}
