package com.web.entity.ReturnResult;

public class WriterList {
    public int id;
    public String name;
    public int permission;
}
