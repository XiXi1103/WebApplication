package com.web.entity.ReturnResult;

public class GroupCreateResult {
}
