package com.web.entity.ReturnResult;

public class MemberList {
    public int id;
    public String name;
    public int permission;
    public String time;
    public String msg;
}
