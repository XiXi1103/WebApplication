package com.web.entity.ReturnResult;

public class PathResult {
    public String path;
}
