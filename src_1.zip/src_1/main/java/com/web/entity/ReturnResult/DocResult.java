package com.web.entity.ReturnResult;

public class DocResult {
    public String msg;
    public String content;
    public String html;
    public boolean success;
    public boolean isCollect;
    public boolean isTemplate;
    public int permission;
}
