package com.web.entity;

public class GroupSearch {
    public String name;
    public int id;

    public GroupSearch() {}

    public GroupSearch(String name, int ID) {
        this.name = name;
        id = ID;
    }
}
