package com.web.entity.vue;

public class Group_vue {
    public String groupName;
    public int userID;
    public String groupContent;
    public int groupId;
}
