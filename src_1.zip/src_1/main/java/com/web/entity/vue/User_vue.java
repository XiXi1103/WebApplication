package com.web.entity.vue;

public class User_vue {
    public String username;
    public String password;
    public String email;
    public String code;
}
