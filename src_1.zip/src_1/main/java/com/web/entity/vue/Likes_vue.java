package com.web.entity.vue;

public class Likes_vue {
    public int userId;
    public int docId;
    public int replyId;
    public boolean isDoc;
    public boolean status;
}
