package com.web.entity.vue;

public class Documentation_vue {
    public String title;
    public String content;
    public String html;
    public String summary;
    public int permission;
    public int authorID;
    public int docID;
    public int userID;
    public int otherPermission;
    public int groupId;
    public boolean isTemplate;
}
