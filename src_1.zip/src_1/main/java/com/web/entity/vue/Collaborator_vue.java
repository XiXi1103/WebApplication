package com.web.entity.vue;

public class Collaborator_vue {
    public int userId1;
    public int userId2;
    public int docId;
}
